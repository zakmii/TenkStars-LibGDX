<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="level1" tilewidth="16" tileheight="16" spacing="2" margin="1" tilecount="8160" columns="136">
 <image source="tileset_level.png" width="2460" height="1080"/>
</tileset>
